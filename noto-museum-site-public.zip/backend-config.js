window.NOTO_MUSEUM_BACKEND = {
  provider: "supabase",
  supabaseUrl: "https://hbivbyippiuwpmkbcnvh.supabase.co",
  supabaseAnonKey: "sb_publishable_nc4XOim2AMFHb4YQYzAmkw_jMA2I_kx",
  editorEmail: "k978883@kansai-u.ac.jp",
  table: "noto_spots",
  bucket: "noto-spot-photos",
};
