const STORAGE_KEY = "noto-atlas-spots-v2";
const EDITOR_PASSKEY = "noto2026";
const EDITOR_SESSION_KEY = "noto-museum-editor-unlocked";
const backendConfig = window.NOTO_MUSEUM_BACKEND || {};
const cloud = {
  enabled: false,
  client: null,
  table: backendConfig.table || "noto_spots",
  bucket: backendConfig.bucket || "noto-spot-photos",
  editorEmail: backendConfig.editorEmail || "",
  channel: null,
};

const ui = {
  en: {
    siteTitle: "Noto no Oto Museum Digital Map",
    eyebrow: "Inbound map CMS",
    details: "Details",
    language: "Language",
    role: "Role",
    viewer: "Viewer",
    editor: "Editor",
    openEditorPanel: "Open editor",
    backToViewer: "Viewer mode",
    regionEyebrow: "Noto Peninsula",
    regionTitle: "Coast, craft, food and satoyama life",
    regionCopy:
      "A visitor-facing map for the peninsula's seascapes, hot springs, morning markets, terraced rice fields and living craft culture.",
    groups: "Groups",
    all: "All",
    spots: "Photos",
    newSpot: "Insert photo",
    editorPanel: "Editor panel",
    addOrEdit: "Add photo to map",
    autoTranslate: "Auto translate",
    translateNow: "Update translations",
    titleEn: "English title",
    titleKo: "Korean title",
    titleZh: "Chinese title",
    titleJa: "Title",
    descriptionEn: "English description",
    descriptionKo: "Korean description",
    descriptionZh: "Chinese description",
    descriptionJa: "Description",
    group: "Group",
    municipalityJa: "Japanese municipality",
    municipalityEn: "English municipality",
    municipalityKo: "Korean municipality",
    municipalityZh: "Chinese municipality",
    latitude: "Latitude",
    longitude: "Longitude",
    locationInfo: "Location info",
    pickOnMap: "Pick on map",
    currentLocation: "Use current location",
    useCenter: "Use center",
    photoUrl: "Photo URL",
    uploadPhoto: "Photo upload",
    choosePhoto: "Choose photos",
    delete: "Delete",
    reset: "Reset",
    save: "Show on map",
    previewEmpty: "Inserted photo preview",
    edit: "Edit",
    noSpots: "No photos yet.",
    saved: "Photo saved.",
    deleted: "Photo deleted.",
    uploadFailed: "Could not insert this photo.",
    imported: "Imported map data.",
    exportReady: "Map data exported.",
    pickPrompt: "Click the map to set latitude and longitude.",
    picked: "Location set.",
    centerUsed: "Map center copied.",
    invalidLocation: "Enter latitude and longitude, like 37.000000, 136.000000.",
    locationRequired: "Add location info first.",
    photoLocationFound: "Photo location was added.",
    photoLocationMissing: "No location data was found in this photo.",
    currentLocationFailed: "Could not get current location.",
    postComplete: "Post complete. The photo is now on the map.",
    viewerMode: "Viewer mode hides editing controls.",
    editorMode: "Editor mode is active.",
    editorAccess: "Editor access",
    editorPasskeyTitle: "Enter editor password",
    editorPasskeyCopy: "Editor tools are separated from the public viewer.",
    editorEmailLabel: "Editor email",
    editorPasskeyLabel: "Password",
    editorPasskeyError: "Password is incorrect.",
    editorLocked: "Editor mode requires a password.",
    editorLoggedOut: "Editor locked. Viewer mode is active.",
    unlockEditor: "Unlock editor",
    cancel: "Cancel",
    cloudConnected: "Shared database connected.",
    cloudUnavailable: "Shared database is not configured. Using this browser only.",
    cloudSyncFailed: "Could not sync the shared database.",
    editorSignInFailed: "Could not sign in as editor.",
    editorSignedOut: "Editor signed out.",
    uploadingToCloud: "Uploading photos to shared storage.",
    translating: "Translating from Japanese.",
    translated: "Translations updated.",
  },
  ko: {
    siteTitle: "노토노오토 미술관 디지털 맵",
    eyebrow: "인바운드 지도 CMS",
    details: "상세",
    language: "언어",
    role: "권한",
    viewer: "열람자",
    editor: "편집자",
    openEditorPanel: "편집자 화면 열기",
    backToViewer: "열람자 모드",
    regionEyebrow: "노토반도",
    regionTitle: "해안, 공예, 음식, 사토야마의 생활",
    regionCopy:
      "바다 풍경, 온천, 아침시장, 계단식 논, 살아 있는 공예 문화를 소개하는 방문자용 지도입니다.",
    groups: "그룹",
    all: "전체",
    spots: "사진",
    newSpot: "사진 삽입",
    editorPanel: "편집 패널",
    addOrEdit: "지도에 사진 추가",
    autoTranslate: "자동 번역",
    translateNow: "번역 업데이트",
    titleEn: "영어 제목",
    titleKo: "한국어 제목",
    titleZh: "중국어 제목",
    titleJa: "제목",
    descriptionEn: "영어 설명",
    descriptionKo: "한국어 설명",
    descriptionZh: "중국어 설명",
    descriptionJa: "설명",
    group: "그룹",
    municipalityJa: "일본어 지역",
    municipalityEn: "영어 지역",
    municipalityKo: "한국어 지역",
    municipalityZh: "중국어 지역",
    latitude: "위도",
    longitude: "경도",
    locationInfo: "위치 정보",
    pickOnMap: "지도에서 선택",
    currentLocation: "현재 위치 사용",
    useCenter: "중앙값 사용",
    photoUrl: "사진 URL",
    uploadPhoto: "사진 업로드",
    choosePhoto: "사진 여러 장 선택",
    delete: "삭제",
    reset: "초기화",
    save: "지도에 표시",
    previewEmpty: "삽입한 사진 미리보기",
    edit: "편집",
    noSpots: "아직 사진이 없습니다.",
    saved: "사진을 저장했습니다.",
    deleted: "사진을 삭제했습니다.",
    uploadFailed: "이 사진을 삽입할 수 없습니다.",
    imported: "지도 데이터를 가져왔습니다.",
    exportReady: "지도 데이터를 내보냈습니다.",
    pickPrompt: "지도에서 위치를 클릭해 위도와 경도를 설정하세요.",
    picked: "위치를 설정했습니다.",
    centerUsed: "지도의 중앙 좌표를 복사했습니다.",
    invalidLocation: "37.000000, 136.000000 형식으로 위도와 경도를 입력하세요.",
    locationRequired: "먼저 위치 정보를 입력하세요.",
    photoLocationFound: "사진의 위치 정보를 추가했습니다.",
    photoLocationMissing: "이 사진에서 위치 정보를 찾을 수 없습니다.",
    currentLocationFailed: "현재 위치를 가져올 수 없습니다.",
    postComplete: "게시가 완료되었습니다. 사진이 지도에 표시됩니다.",
    viewerMode: "열람자 모드에서는 편집 도구가 숨겨집니다.",
    editorMode: "편집자 모드가 활성화되었습니다.",
    editorAccess: "편집자 접근",
    editorPasskeyTitle: "편집자 비밀번호 입력",
    editorPasskeyCopy: "편집 도구는 열람자 사이트와 분리되어 있습니다.",
    editorEmailLabel: "편집자 이메일",
    editorPasskeyLabel: "비밀번호",
    editorPasskeyError: "비밀번호가 올바르지 않습니다.",
    editorLocked: "편집자 모드에는 비밀번호가 필요합니다.",
    editorLoggedOut: "편집자가 잠겼습니다. 열람자 모드가 활성화되었습니다.",
    unlockEditor: "편집자 잠금 해제",
    cancel: "취소",
    cloudConnected: "공유 데이터베이스에 연결되었습니다.",
    cloudUnavailable: "공유 데이터베이스가 설정되지 않았습니다. 이 브라우저에만 저장됩니다.",
    cloudSyncFailed: "공유 데이터베이스와 동기화할 수 없습니다.",
    editorSignInFailed: "편집자로 로그인할 수 없습니다.",
    editorSignedOut: "편집자 로그아웃이 완료되었습니다.",
    uploadingToCloud: "사진을 공유 스토리지에 업로드하고 있습니다.",
    translating: "일본어 원고를 번역하고 있습니다.",
    translated: "번역을 업데이트했습니다.",
  },
  zh: {
    siteTitle: "能登之音美术馆数字地图",
    eyebrow: "入境游客地图 CMS",
    details: "详细",
    language: "语言",
    role: "权限",
    viewer: "浏览者",
    editor: "编辑者",
    openEditorPanel: "打开编辑者页面",
    backToViewer: "浏览者模式",
    regionEyebrow: "能登半岛",
    regionTitle: "海岸、工艺、美食与里山生活",
    regionCopy:
      "面向游客的地图，用于展示半岛海景、温泉、早市、梯田和仍在延续的工艺文化。",
    groups: "分组",
    all: "全部",
    spots: "照片",
    newSpot: "插入照片",
    editorPanel: "编辑面板",
    addOrEdit: "将照片添加到地图",
    autoTranslate: "自动翻译",
    translateNow: "更新翻译",
    titleEn: "英文标题",
    titleKo: "韩文标题",
    titleZh: "中文标题",
    titleJa: "标题",
    descriptionEn: "英文说明",
    descriptionKo: "韩文说明",
    descriptionZh: "中文说明",
    descriptionJa: "说明",
    group: "分组",
    municipalityJa: "日文地区",
    municipalityEn: "英文地区",
    municipalityKo: "韩文地区",
    municipalityZh: "中文地区",
    latitude: "纬度",
    longitude: "经度",
    locationInfo: "位置信息",
    pickOnMap: "在地图选择",
    currentLocation: "使用当前位置",
    useCenter: "使用中心点",
    photoUrl: "照片 URL",
    uploadPhoto: "上传照片",
    choosePhoto: "选择多张照片",
    delete: "删除",
    reset: "重置",
    save: "显示在地图上",
    previewEmpty: "已插入照片预览",
    edit: "编辑",
    noSpots: "尚无照片。",
    saved: "照片已保存。",
    deleted: "照片已删除。",
    uploadFailed: "无法插入此照片。",
    imported: "已导入地图数据。",
    exportReady: "地图数据已导出。",
    pickPrompt: "点击地图设置纬度和经度。",
    picked: "位置已设置。",
    centerUsed: "已复制地图中心坐标。",
    invalidLocation: "请输入纬度和经度，例如 37.000000, 136.000000。",
    locationRequired: "请先添加位置信息。",
    photoLocationFound: "已添加照片位置信息。",
    photoLocationMissing: "此照片中未找到位置信息。",
    currentLocationFailed: "无法获取当前位置。",
    postComplete: "发布完成。照片已显示在地图上。",
    viewerMode: "浏览者模式会隐藏编辑控件。",
    editorMode: "编辑者模式已启用。",
    editorAccess: "编辑者访问",
    editorPasskeyTitle: "输入编辑者密码",
    editorPasskeyCopy: "编辑工具与浏览者页面分开。",
    editorEmailLabel: "编辑者邮箱",
    editorPasskeyLabel: "密码",
    editorPasskeyError: "密码不正确。",
    editorLocked: "编辑者模式需要密码。",
    editorLoggedOut: "编辑者已锁定。浏览者模式已启用。",
    unlockEditor: "解锁编辑者",
    cancel: "取消",
    cloudConnected: "已连接共享数据库。",
    cloudUnavailable: "未配置共享数据库。仅保存在此浏览器中。",
    cloudSyncFailed: "无法同步共享数据库。",
    editorSignInFailed: "无法以编辑者身份登录。",
    editorSignedOut: "编辑者已退出登录。",
    uploadingToCloud: "正在将照片上传到共享存储。",
    translating: "正在从日语翻译。",
    translated: "翻译已更新。",
  },
  ja: {
    siteTitle: "のとのおと美術館デジタルマップ",
    eyebrow: "インバウンド地図 CMS",
    details: "詳細",
    language: "言語",
    role: "権限",
    viewer: "閲覧者",
    editor: "編集者",
    openEditorPanel: "編集者画面を開く",
    backToViewer: "閲覧者に戻る",
    regionEyebrow: "能登半島",
    regionTitle: "海、工芸、食、里山里海の暮らし",
    regionCopy:
      "海岸景観、温泉、朝市、棚田、工芸文化を訪日客へ届けるための地図です。",
    groups: "グループ",
    all: "すべて",
    spots: "写真",
    newSpot: "写真を挿入",
    editorPanel: "編集パネル",
    addOrEdit: "写真を地図に追加",
    autoTranslate: "自動翻訳",
    translateNow: "翻訳を更新",
    titleEn: "タイトル（英語）",
    titleKo: "タイトル（韓国語）",
    titleZh: "タイトル（中国語）",
    titleJa: "タイトル",
    descriptionEn: "説明（英語）",
    descriptionKo: "説明（韓国語）",
    descriptionZh: "説明（中国語）",
    descriptionJa: "説明",
    group: "グループ",
    municipalityJa: "市区町村（日本語）",
    municipalityEn: "市区町村（英語）",
    municipalityKo: "市区町村（韓国語）",
    municipalityZh: "市区町村（中国語）",
    latitude: "緯度",
    longitude: "経度",
    locationInfo: "位置情報",
    pickOnMap: "地図で指定",
    currentLocation: "現在地を使用",
    useCenter: "中心を使用",
    photoUrl: "写真URL",
    uploadPhoto: "写真アップロード",
    choosePhoto: "写真を複数選択",
    delete: "削除",
    reset: "リセット",
    save: "地図に表示",
    previewEmpty: "挿入写真のプレビュー",
    edit: "編集",
    noSpots: "まだ写真がありません。",
    saved: "写真を保存しました。",
    deleted: "写真を削除しました。",
    uploadFailed: "この写真を挿入できませんでした。",
    imported: "地図データを読み込みました。",
    exportReady: "地図データを書き出しました。",
    pickPrompt: "地図をクリックして緯度・経度を設定してください。",
    picked: "位置を設定しました。",
    centerUsed: "地図中心の座標を反映しました。",
    invalidLocation: "37.000000, 136.000000 の形式で緯度・経度を入力してください。",
    locationRequired: "先に位置情報を入力してください。",
    photoLocationFound: "写真の位置情報を反映しました。",
    photoLocationMissing: "この写真には位置情報が見つかりませんでした。",
    currentLocationFailed: "現在地を取得できませんでした。",
    postComplete: "投稿が完了しました。写真を地図に表示しました。",
    viewerMode: "閲覧者モードでは編集操作を非表示にします。",
    editorMode: "編集者モードが有効です。",
    editorAccess: "編集者アクセス",
    editorPasskeyTitle: "編集者パスワードを入力",
    editorPasskeyCopy: "編集ツールは閲覧者用サイトとは別にしています。",
    editorEmailLabel: "編集者メール",
    editorPasskeyLabel: "パスワード",
    editorPasskeyError: "パスワードが正しくありません。",
    editorLocked: "編集者モードにはパスワードが必要です。",
    editorLoggedOut: "編集者をロックしました。閲覧者モードです。",
    unlockEditor: "編集者を開く",
    cancel: "キャンセル",
    cloudConnected: "共有データベースに接続しました。",
    cloudUnavailable: "共有データベースは未設定です。このブラウザ内に保存します。",
    cloudSyncFailed: "共有データベースと同期できませんでした。",
    editorSignInFailed: "編集者としてログインできませんでした。",
    editorSignedOut: "編集者ログアウトしました。",
    uploadingToCloud: "写真を共有ストレージへアップロードしています。",
    translating: "日本語原稿から翻訳しています。",
    translated: "翻訳を更新しました。",
  },
};

const groups = {
  coast: {
    icon: "waves",
    labels: { en: "Coast", ko: "해안", zh: "海岸", ja: "海岸" },
  },
  culture: {
    icon: "landmark",
    labels: { en: "Craft & heritage", ko: "공예와 역사", zh: "工艺与历史", ja: "工芸と歴史" },
  },
  food: {
    icon: "utensils",
    labels: { en: "Food & markets", ko: "음식과 시장", zh: "美食与市场", ja: "食と市場" },
  },
  onsen: {
    icon: "bath",
    labels: { en: "Hot springs", ko: "온천", zh: "温泉", ja: "温泉" },
  },
  satoyama: {
    icon: "sprout",
    labels: { en: "Satoyama", ko: "사토야마", zh: "里山", ja: "里山里海" },
  },
};

const initialSpots = [];

const translationTargets = ["en", "ko", "zh"];
const translatorCache = new Map();
const translationMemory = new Map();
const glossaryTerms = {
  en: [
    ["能登半島", "Noto Peninsula"],
    ["能登", "Noto"],
    ["のとのおと美術館デジタルマップ", "Noto no Oto Museum Digital Map"],
    ["白米千枚田", "Shiroyone Senmaida Rice Terraces"],
    ["見附島", "Mitsukejima Island"],
    ["輪島朝市", "Wajima Morning Market"],
    ["輪島", "Wajima"],
    ["珠洲", "Suzu"],
    ["七尾湾", "Nanao Bay"],
    ["和倉温泉", "Wakura Onsen"],
    ["千里浜なぎさドライブウェイ", "Chirihama Nagisa Driveway"],
    ["海岸", "coast"],
    ["温泉", "hot spring"],
    ["工芸", "craft"],
    ["棚田", "rice terraces"],
    ["朝市", "morning market"],
    ["写真", "photo"],
    ["美術館", "museum of art"],
  ],
  ko: [
    ["能登半島", "노토반도"],
    ["能登", "노토"],
    ["のとのおと美術館デジタルマップ", "노토노오토 미술관 디지털 맵"],
    ["白米千枚田", "시로요네 센마이다"],
    ["見附島", "미쓰케지마"],
    ["輪島朝市", "와지마 아침시장"],
    ["輪島", "와지마"],
    ["珠洲", "스즈"],
    ["七尾湾", "나나오만"],
    ["和倉温泉", "와쿠라 온천"],
    ["千里浜なぎさドライブウェイ", "치리하마 나기사 드라이브웨이"],
    ["海岸", "해안"],
    ["温泉", "온천"],
    ["工芸", "공예"],
    ["棚田", "계단식 논"],
    ["朝市", "아침시장"],
    ["写真", "사진"],
    ["美術館", "미술관"],
  ],
  zh: [
    ["能登半島", "能登半岛"],
    ["能登", "能登"],
    ["のとのおと美術館デジタルマップ", "能登之音美术馆数字地图"],
    ["白米千枚田", "白米千枚田"],
    ["見附島", "见附岛"],
    ["輪島朝市", "轮岛早市"],
    ["輪島", "轮岛"],
    ["珠洲", "珠洲"],
    ["七尾湾", "七尾湾"],
    ["和倉温泉", "和仓温泉"],
    ["千里浜なぎさドライブウェイ", "千里滨海滩车道"],
    ["海岸", "海岸"],
    ["温泉", "温泉"],
    ["工芸", "工艺"],
    ["棚田", "梯田"],
    ["朝市", "早市"],
    ["写真", "照片"],
    ["美術館", "美术馆"],
  ],
};

translationMemory.set("のとのおと美術館デジタルマップ", {
  en: "Noto no Oto Museum Digital Map",
  ko: "노토노오토 미술관 디지털 맵",
  zh: "能登之音美术馆数字地图",
});
translationMemory.set("能登半島の海岸と工芸を紹介する美術館です。", {
  en: "A museum of art introducing the Noto Peninsula's coast and craft culture.",
  ko: "노토반도의 해안과 공예 문화를 소개하는 미술관입니다.",
  zh: "这是一座介绍能登半岛海岸与工艺文化的美术馆。",
});
[
  ["輪島市", "Wajima City", "와지마시", "轮岛市"],
  ["珠洲市", "Suzu City", "스즈시", "珠洲市"],
  ["七尾市", "Nanao City", "나나오시", "七尾市"],
  ["羽咋市", "Hakui City", "하쿠이시", "羽咋市"],
  ["能登町", "Noto Town", "노토정", "能登町"],
  ["穴水町", "Anamizu Town", "아나미즈정", "穴水町"],
  ["志賀町", "Shika Town", "시카정", "志贺町"],
  ["中能登町", "Nakanoto Town", "나카노토정", "中能登町"],
  ["宝達志水町", "Hodatsushimizu Town", "호다쓰시미즈정", "宝达志水町"],
].forEach(([ja, en, ko, zh]) => {
  translationMemory.set(ja, { en, ko, zh });
});

function readEditorSession() {
  try {
    return sessionStorage.getItem(EDITOR_SESSION_KEY) === "true";
  } catch {
    return false;
  }
}

function writeEditorSession(isUnlocked) {
  try {
    if (isUnlocked) {
      sessionStorage.setItem(EDITOR_SESSION_KEY, "true");
    } else {
      sessionStorage.removeItem(EDITOR_SESSION_KEY);
    }
  } catch {
    // If sessionStorage is unavailable, keep the unlock state in memory only.
  }
}

const state = {
  lang: "ja",
  role: "viewer",
  editorUnlocked: readEditorSession(),
  cloudUser: null,
  openEditorAfterUnlock: false,
  activeGroup: null,
  selectedId: null,
  draftImages: [],
  picking: false,
  spots: loadSpots(),
};

const els = {
  languageSelect: document.querySelector("#languageSelect"),
  detailsMenu: document.querySelector("#detailsMenu"),
  roleSelect: document.querySelector("#roleSelect"),
  viewerModeButton: document.querySelector("#viewerModeButton"),
  editorModeButton: document.querySelector("#editorModeButton"),
  exportButton: document.querySelector("#exportButton"),
  importInput: document.querySelector("#importInput"),
  clearFilterButton: document.querySelector("#clearFilterButton"),
  groupList: document.querySelector("#groupList"),
  spotList: document.querySelector("#spotList"),
  newSpotButton: document.querySelector("#newSpotButton"),
  editorDrawer: document.querySelector("#editorDrawer"),
  closeDrawerButton: document.querySelector("#closeDrawerButton"),
  spotForm: document.querySelector("#spotForm"),
  spotId: document.querySelector("#spotId"),
  titleEn: document.querySelector("#titleEn"),
  titleKo: document.querySelector("#titleKo"),
  titleZh: document.querySelector("#titleZh"),
  titleJa: document.querySelector("#titleJa"),
  autoTranslateToggle: document.querySelector("#autoTranslateToggle"),
  translateButton: document.querySelector("#translateButton"),
  descriptionEn: document.querySelector("#descriptionEn"),
  descriptionKo: document.querySelector("#descriptionKo"),
  descriptionZh: document.querySelector("#descriptionZh"),
  descriptionJa: document.querySelector("#descriptionJa"),
  spotGroup: document.querySelector("#spotGroup"),
  municipalityEn: document.querySelector("#municipalityEn"),
  municipalityKo: document.querySelector("#municipalityKo"),
  municipalityZh: document.querySelector("#municipalityZh"),
  municipalityJa: document.querySelector("#municipalityJa"),
  locationInfo: document.querySelector("#locationInfo"),
  latitude: document.querySelector("#latitude"),
  longitude: document.querySelector("#longitude"),
  pickOnMapButton: document.querySelector("#pickOnMapButton"),
  currentLocationButton: document.querySelector("#currentLocationButton"),
  useCenterButton: document.querySelector("#useCenterButton"),
  photoUrl: document.querySelector("#photoUrl"),
  photoFile: document.querySelector("#photoFile"),
  photoPreview: document.querySelector("#photoPreview"),
  deleteButton: document.querySelector("#deleteButton"),
  resetButton: document.querySelector("#resetButton"),
  mapStatus: document.querySelector("#mapStatus"),
  completionToast: document.querySelector("#completionToast"),
  imageLightbox: document.querySelector("#imageLightbox"),
  imageLightboxImage: document.querySelector("#imageLightboxImage"),
  imageLightboxCaption: document.querySelector("#imageLightboxCaption"),
  imageLightboxClose: document.querySelector("#imageLightboxClose"),
  passkeyModal: document.querySelector("#passkeyModal"),
  passkeyForm: document.querySelector("#passkeyForm"),
  editorEmailInput: document.querySelector("#editorEmailInput"),
  editorPasskeyInput: document.querySelector("#editorPasskeyInput"),
  passkeyError: document.querySelector("#passkeyError"),
  passkeyCancelButton: document.querySelector("#passkeyCancelButton"),
};

const map = L.map("map", {
  zoomControl: false,
  scrollWheelZoom: true,
}).setView([37.17, 136.99], 9);

L.control.zoom({ position: "bottomright" }).addTo(map);

L.tileLayer("https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png", {
  maxZoom: 19,
  attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a>',
}).addTo(map);

const clusterLayer = L.markerClusterGroup({
  maxClusterRadius: 52,
  showCoverageOnHover: false,
  spiderfyDistanceMultiplier: 1.2,
});
map.addLayer(clusterLayer);

let statusTimer;
let pickHandler;
let translationTimer;
let draftMarker;

function loadSpots() {
  try {
    const stored = JSON.parse(localStorage.getItem(STORAGE_KEY) || "null");
    return Array.isArray(stored) ? stored : [];
  } catch {
    return [];
  }
}

function saveSpots() {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(state.spots));
    return true;
  } catch {
    showStatus(t("uploadFailed"));
    return false;
  }
}

function hasCloudConfig() {
  return (
    backendConfig.provider === "supabase" &&
    Boolean(backendConfig.supabaseUrl) &&
    Boolean(backendConfig.supabaseAnonKey)
  );
}

function isCloudEditorUnlocked() {
  return cloud.enabled ? Boolean(state.cloudUser) || state.editorUnlocked : state.editorUnlocked;
}

function cloudRowToSpot(row) {
  const payload = row?.payload && typeof row.payload === "object" ? row.payload : {};
  return {
    ...payload,
    id: row.id || payload.id,
  };
}

async function loadCloudSpots() {
  if (!cloud.enabled) return false;
  const { data, error } = await cloud.client
    .from(cloud.table)
    .select("id,payload,updated_at")
    .order("updated_at", { ascending: false });
  if (error) throw error;
  state.spots = (data || [])
    .map(cloudRowToSpot)
    .filter((spot) => spot.id && Number.isFinite(Number(spot.lat)) && Number.isFinite(Number(spot.lng)));
  saveSpots();
  state.selectedId = state.spots.some((spot) => spot.id === state.selectedId) ? state.selectedId : null;
  renderAll();
  return true;
}

function dataUrlToBlob(dataUrl) {
  const [header, base64] = String(dataUrl).split(",");
  const mime = header.match(/data:(.*?);base64/)?.[1] || "image/jpeg";
  const binary = atob(base64 || "");
  const bytes = new Uint8Array(binary.length);
  for (let index = 0; index < binary.length; index += 1) {
    bytes[index] = binary.charCodeAt(index);
  }
  return new Blob([bytes], { type: mime });
}

function imageExtension(mime) {
  if (mime.includes("png")) return "png";
  if (mime.includes("webp")) return "webp";
  return "jpg";
}

async function uploadSpotImages(spot) {
  if (!cloud.enabled) return spot;
  const images = spotImages(spot);
  if (!images.some((image) => image.startsWith("data:image/"))) return spot;
  showStatus(t("uploadingToCloud"));
  const uploadedImages = [];
  for (const [index, image] of images.entries()) {
    if (!image.startsWith("data:image/")) {
      uploadedImages.push(image);
      continue;
    }
    const blob = dataUrlToBlob(image);
    const extension = imageExtension(blob.type);
    const filePath = `${spot.id}/${Date.now()}-${index}.${extension}`;
    const { error } = await cloud.client.storage.from(cloud.bucket).upload(filePath, blob, {
      contentType: blob.type,
      upsert: true,
    });
    if (error) throw error;
    const { data } = cloud.client.storage.from(cloud.bucket).getPublicUrl(filePath);
    uploadedImages.push(data.publicUrl);
  }
  return {
    ...spot,
    image: uploadedImages[0] || "",
    images: uploadedImages,
  };
}

async function persistCloudSpot(spot) {
  const cloudSpot = await uploadSpotImages(spot);
  const { error } = await cloud.client.from(cloud.table).upsert(
    {
      id: cloudSpot.id,
      payload: cloudSpot,
      updated_at: new Date().toISOString(),
    },
    { onConflict: "id" },
  );
  if (error) throw error;
  return cloudSpot;
}

async function deleteCloudSpot(id) {
  const { error } = await cloud.client.from(cloud.table).delete().eq("id", id);
  if (error) throw error;
}

async function initializeCloudBackend() {
  if (!hasCloudConfig()) {
    document.body.classList.remove("cloud-enabled");
    return;
  }
  if (!window.supabase?.createClient) {
    showStatus(t("cloudSyncFailed"));
    return;
  }
  cloud.enabled = true;
  cloud.client = window.supabase.createClient(backendConfig.supabaseUrl, backendConfig.supabaseAnonKey);
  document.body.classList.add("cloud-enabled");
  els.editorEmailInput.value = cloud.editorEmail;
  els.editorEmailInput.required = false;

  try {
    const { data } = await cloud.client.auth.getSession();
    state.cloudUser = data.session?.user || null;
    state.editorUnlocked = state.editorUnlocked || Boolean(state.cloudUser);
    await loadCloudSpots();
    showStatus(t("cloudConnected"));
  } catch {
    showStatus(t("cloudSyncFailed"));
  }

  cloud.client.auth.onAuthStateChange((_event, session) => {
    state.cloudUser = session?.user || null;
    if (state.cloudUser) state.editorUnlocked = true;
    if (!state.cloudUser && !state.editorUnlocked && state.role === "editor") setRole("viewer");
  });

  cloud.channel = cloud.client
    .channel("noto-spots-map")
    .on("postgres_changes", { event: "*", schema: "public", table: cloud.table }, () => {
      loadCloudSpots().catch(() => showStatus(t("cloudSyncFailed")));
    })
    .subscribe();
}

function t(key) {
  return ui[state.lang][key] || ui.en[key] || key;
}

function localize(value) {
  if (!value || typeof value !== "object") return "";
  return value[state.lang] || value.en || value.ja || Object.values(value)[0] || "";
}

function localizeMunicipality(value) {
  if (!value) return "";
  if (typeof value === "string") return value;
  return localize(value);
}

function groupLabel(groupKey) {
  return groups[groupKey]?.labels[state.lang] || groups[groupKey]?.labels.en || groupKey;
}

function visibleSpots() {
  return state.activeGroup
    ? state.spots.filter((spot) => spot.group === state.activeGroup)
    : state.spots;
}

function escapeHtml(value) {
  return String(value ?? "")
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;")
    .replaceAll("'", "&#039;");
}

function safeImageSource(value) {
  const source = String(value || "").trim();
  if (!source) return "";
  if (/^(https?:\/\/|data:image\/)/i.test(source)) return source;
  return "";
}

function spotImages(spot) {
  if (!spot) return [];
  if (Array.isArray(spot.images) && spot.images.length) return spot.images.filter(safeImageSource);
  return safeImageSource(spot.image) ? [spot.image] : [];
}

function primaryImage(spot) {
  return spotImages(spot)[0] || "";
}

function makeImage(source, alt, className = "") {
  const safeSource = safeImageSource(source);
  if (!safeSource) return `<div class="${className}" aria-label="${escapeHtml(t("previewEmpty"))}"></div>`;
  return `
    <div class="${className}">
      <img src="${escapeHtml(safeSource)}" alt="${escapeHtml(alt)}" loading="lazy" decoding="async" onerror="this.remove()" />
    </div>
  `;
}

function makePhotoGallery(images, alt, className = "") {
  const safeImages = images.map(safeImageSource).filter(Boolean);
  if (!safeImages.length) return `<div class="${className}" aria-label="${escapeHtml(t("previewEmpty"))}"></div>`;
  return `
    <div class="${className} photo-gallery">
      ${safeImages
        .map(
          (source, index) => `
            <img src="${escapeHtml(source)}" alt="${escapeHtml(`${alt} ${index + 1}`)}" loading="lazy" decoding="async" />
          `,
        )
        .join("")}
    </div>
  `;
}

function markerIcon(spot) {
  const groupKey = spot.group;
  const images = spotImages(spot);
  const thumbnail = safeImageSource(images[0]);
  const title = localize(spot.title);
  if (thumbnail) {
    const countBadge =
      images.length > 1 ? `<span class="photo-marker-count" aria-label="${escapeHtml(`${images.length} photos`)}">${images.length}</span>` : "";
    return L.divIcon({
      className: "",
      html: `
        <div class="custom-marker photo-marker ${escapeHtml(groupKey)}">
          <span class="photo-marker-frame">
            <img src="${escapeHtml(thumbnail)}" alt="${escapeHtml(title)}" width="50" height="50" loading="lazy" decoding="async" onerror="this.closest('.photo-marker').classList.add('image-failed'); this.remove()" />
            <i class="marker-fallback" data-lucide="image"></i>
          </span>
          ${countBadge}
        </div>
      `,
      iconSize: [58, 66],
      iconAnchor: [29, 64],
      popupAnchor: [0, -62],
    });
  }

  const iconName = groups[groupKey]?.icon || "map-pin";
  return L.divIcon({
    className: "",
    html: `<div class="custom-marker ${escapeHtml(groupKey)}"><i data-lucide="${escapeHtml(iconName)}"></i></div>`,
    iconSize: [34, 34],
    iconAnchor: [17, 34],
    popupAnchor: [0, -32],
  });
}

function popupHtml(spot) {
  const title = localize(spot.title);
  const municipality = localizeMunicipality(spot.municipality);
  const images = spotImages(spot);
  return `
    <article class="popup">
      ${makePhotoGallery(images, title, "popup-thumb")}
      <div>
        <h3>${escapeHtml(title)}</h3>
        <p>${escapeHtml(localize(spot.description))}</p>
      </div>
      <div class="popup-footer">
        <span class="popup-tags">
          <span class="tag">${escapeHtml(groupLabel(spot.group))}</span>
          ${municipality ? `<span class="tag">${escapeHtml(municipality)}</span>` : ""}
          ${images.length > 1 ? `<span class="tag">${images.length}枚</span>` : ""}
        </span>
        <button class="secondary-button editor-only" type="button" data-edit-spot="${escapeHtml(spot.id)}">
          ${escapeHtml(t("edit"))}
        </button>
      </div>
    </article>
  `;
}

function renderMap() {
  clusterLayer.clearLayers();
  visibleSpots().forEach((spot) => {
    const marker = L.marker([spot.lat, spot.lng], { icon: markerIcon(spot) });
    marker.bindPopup(popupHtml(spot), { maxWidth: 280 });
    marker.on("click", () => {
      state.selectedId = spot.id;
      renderSpotList();
    });
    clusterLayer.addLayer(marker);
  });
  requestAnimationFrame(() => {
    if (window.lucide) window.lucide.createIcons();
  });
}

function renderGroups() {
  const counts = state.spots.reduce((acc, spot) => {
    acc[spot.group] = (acc[spot.group] || 0) + 1;
    return acc;
  }, {});

  els.groupList.innerHTML = Object.keys(groups)
    .map((key) => {
      const active = state.activeGroup === key ? " active" : "";
      return `
        <button class="group-button${active}" type="button" data-group="${escapeHtml(key)}">
          <strong>${escapeHtml(groupLabel(key))}</strong>
          <span>${counts[key] || 0}</span>
        </button>
      `;
    })
    .join("");
}

function renderSpotList() {
  const spots = visibleSpots();
  if (!spots.length) {
    els.spotList.innerHTML = `<p class="empty">${escapeHtml(t("noSpots"))}</p>`;
    return;
  }

  els.spotList.innerHTML = spots
    .map((spot) => {
      const title = localize(spot.title);
      const municipality = localizeMunicipality(spot.municipality);
      const images = spotImages(spot);
      const active = state.selectedId === spot.id ? " active" : "";
      return `
        <button class="spot-card${active}" type="button" data-spot="${escapeHtml(spot.id)}">
          ${makeImage(primaryImage(spot), title, "spot-thumb")}
          <div class="spot-meta">
            <h3>${escapeHtml(title)}</h3>
            <p>${escapeHtml(localize(spot.description))}</p>
            <div class="spot-tags">
              <span class="tag">${escapeHtml(groupLabel(spot.group))}</span>
              ${municipality ? `<span class="tag">${escapeHtml(municipality)}</span>` : ""}
              ${images.length > 1 ? `<span class="tag">${images.length}枚</span>` : ""}
            </div>
          </div>
        </button>
      `;
    })
    .join("");
}

function renderGroupOptions() {
  const currentValue = els.spotGroup.value;
  els.spotGroup.innerHTML = Object.keys(groups)
    .map((key) => `<option value="${escapeHtml(key)}">${escapeHtml(groupLabel(key))}</option>`)
    .join("");
  if (currentValue && groups[currentValue]) els.spotGroup.value = currentValue;
}

function renderI18n() {
  document.documentElement.lang = state.lang;
  document.title = t("siteTitle");
  document.querySelectorAll("[data-i18n]").forEach((node) => {
    const key = node.getAttribute("data-i18n");
    node.textContent = t(key);
  });
  renderGroupOptions();
  renderGroups();
  renderSpotList();
  renderMap();
  renderPreview();
}

function renderRole() {
  els.roleSelect.value = state.role;
  document.body.classList.toggle("viewer", state.role === "viewer");
  document.body.classList.toggle("editor", state.role === "editor");
  els.viewerModeButton.classList.toggle("active", state.role === "viewer");
  els.editorModeButton.classList.toggle("active", state.role === "editor");
  els.viewerModeButton.setAttribute("aria-pressed", String(state.role === "viewer"));
  els.editorModeButton.setAttribute("aria-pressed", String(state.role === "editor"));
  if (state.role === "viewer") closeDrawer();
  showStatus(state.role === "editor" ? t("editorMode") : t("viewerMode"));
  setTimeout(() => map.invalidateSize(), 50);
}

function setRole(role) {
  state.role = role;
  renderRole();
}

function openPasskeyDialog() {
  els.passkeyForm.reset();
  els.editorEmailInput.value = cloud.editorEmail;
  els.editorEmailInput.required = false;
  els.passkeyError.hidden = true;
  els.passkeyModal.removeAttribute("aria-hidden");
  document.body.classList.add("passkey-open");
  showStatus(t("editorLocked"));
  window.setTimeout(() => els.editorPasskeyInput.focus(), 30);
}

function closeDetailsMenu() {
  if (els.detailsMenu) els.detailsMenu.open = false;
}

function openEditorWorkspace(reset = true) {
  setRole("editor");
  if (reset) resetForm();
  openDrawer();
  closeDetailsMenu();
}

function requestEditorWorkspace() {
  state.openEditorAfterUnlock = true;
  if (isCloudEditorUnlocked()) {
    openEditorWorkspace();
    state.openEditorAfterUnlock = false;
    return;
  }
  closeDetailsMenu();
  openPasskeyDialog();
}

function closePasskeyDialog() {
  els.passkeyModal.setAttribute("aria-hidden", "true");
  document.body.classList.remove("passkey-open");
  els.passkeyError.hidden = true;
  els.roleSelect.value = state.role;
  state.openEditorAfterUnlock = false;
}

function unlockEditorAccess() {
  const shouldOpenEditor = state.openEditorAfterUnlock;
  state.editorUnlocked = true;
  writeEditorSession(true);
  closePasskeyDialog();
  setRole("editor");
  if (shouldOpenEditor) {
    resetForm();
    openDrawer();
  }
}

function lockEditorAccess() {
  state.editorUnlocked = false;
  state.cloudUser = null;
  writeEditorSession(false);
  if (cloud.enabled) {
    cloud.client.auth.signOut().catch(() => {});
  }
  setRole("viewer");
  showStatus(cloud.enabled ? t("editorSignedOut") : t("editorLoggedOut"));
}

function renderPreview() {
  const urlImage = safeImageSource(els.photoUrl.value);
  const images = state.draftImages.length ? state.draftImages : urlImage ? [urlImage] : [];
  if (!images.length) {
    els.photoPreview.textContent = t("previewEmpty");
    return;
  }
  els.photoPreview.innerHTML = makePhotoGallery(images, t("previewEmpty"), "photo-preview-gallery");
}

function openDrawer() {
  if (state.role !== "editor") return;
  document.body.classList.add("drawer-open");
  els.editorDrawer.removeAttribute("aria-hidden");
  setTimeout(() => map.invalidateSize(), 50);
}

function closeDrawer() {
  document.body.classList.remove("drawer-open");
  els.editorDrawer.setAttribute("aria-hidden", "true");
  setTimeout(() => map.invalidateSize(), 50);
}

function showStatus(message) {
  window.clearTimeout(statusTimer);
  els.mapStatus.textContent = message;
  els.mapStatus.classList.add("visible");
  statusTimer = window.setTimeout(() => {
    els.mapStatus.classList.remove("visible");
  }, 2600);
}

function showCompletionNotification() {
  els.completionToast.querySelector("span").textContent = t("postComplete");
  els.completionToast.classList.add("visible");
  if (window.lucide) window.lucide.createIcons();
  window.setTimeout(() => {
    els.completionToast.classList.remove("visible");
  }, 3600);
}

function openImageLightbox(image) {
  const source = safeImageSource(image?.currentSrc || image?.src);
  if (!source) return;
  const alt = image.alt || "";
  els.imageLightboxImage.src = source;
  els.imageLightboxImage.alt = alt;
  els.imageLightboxCaption.textContent = alt;
  els.imageLightboxCaption.hidden = !alt;
  els.imageLightbox.removeAttribute("aria-hidden");
  document.body.classList.add("lightbox-open");
  if (window.lucide) window.lucide.createIcons();
}

function closeImageLightbox() {
  els.imageLightbox.setAttribute("aria-hidden", "true");
  document.body.classList.remove("lightbox-open");
  els.imageLightboxImage.removeAttribute("src");
  els.imageLightboxImage.alt = "";
  els.imageLightboxCaption.textContent = "";
  els.imageLightboxCaption.hidden = true;
}

function isImageLightboxOpen() {
  return els.imageLightbox.getAttribute("aria-hidden") !== "true";
}

function resetForm(spot = null) {
  const municipality = spot?.municipality;
  const images = spotImages(spot);
  state.draftImages = images;
  els.spotId.value = spot?.id || "";
  els.titleEn.value = spot?.title?.en || "";
  els.titleKo.value = spot?.title?.ko || "";
  els.titleZh.value = spot?.title?.zh || "";
  els.titleJa.value = spot?.title?.ja || "";
  els.descriptionEn.value = spot?.description?.en || "";
  els.descriptionKo.value = spot?.description?.ko || "";
  els.descriptionZh.value = spot?.description?.zh || "";
  els.descriptionJa.value = spot?.description?.ja || "";
  els.spotGroup.value = spot?.group || state.activeGroup || "coast";
  els.municipalityEn.value = typeof municipality === "object" ? municipality.en || "" : municipality || "";
  els.municipalityKo.value = typeof municipality === "object" ? municipality.ko || "" : "";
  els.municipalityZh.value = typeof municipality === "object" ? municipality.zh || "" : "";
  els.municipalityJa.value = typeof municipality === "object" ? municipality.ja || "" : municipality || "";
  if (spot) {
    els.latitude.value = Number(spot.lat).toFixed(6);
    els.longitude.value = Number(spot.lng).toFixed(6);
    els.locationInfo.value = formatCoordinates(spot.lat, spot.lng);
    clearDraftMarker();
  } else {
    els.latitude.value = "";
    els.longitude.value = "";
    els.locationInfo.value = "";
    clearDraftMarker();
  }
  const firstImage = images[0] || "";
  els.photoUrl.value = firstImage && !firstImage.startsWith("data:image/") ? firstImage : "";
  els.photoFile.value = "";
  els.deleteButton.disabled = !spot;
  [
    els.titleEn,
    els.titleKo,
    els.titleZh,
    els.descriptionEn,
    els.descriptionKo,
    els.descriptionZh,
    els.municipalityEn,
    els.municipalityKo,
    els.municipalityZh,
  ].forEach(
    (element) => {
      element.dataset.autoTranslated = spot ? "false" : "true";
    },
  );
  renderPreview();
}

function getSpot(id) {
  return state.spots.find((spot) => spot.id === id);
}

function selectSpot(id, shouldZoom = true) {
  const spot = getSpot(id);
  if (!spot) return;
  state.selectedId = id;
  if (shouldZoom) map.flyTo([spot.lat, spot.lng], Math.max(map.getZoom(), 12), { duration: 0.65 });
  if (state.role === "editor") {
    resetForm(spot);
    openDrawer();
  }
  renderSpotList();
}

function formValue(id) {
  return els[id].value.trim();
}

function buildSpotFromForm() {
  const existingId = formValue("spotId");
  const existingSpot = getSpot(existingId);
  const existingImages = spotImages(existingSpot);
  const urlImage = safeImageSource(formValue("photoUrl"));
  const images = state.draftImages.length ? state.draftImages : urlImage ? [urlImage] : existingImages;
  const baseTitle = formValue("titleJa") || formValue("titleEn");
  const baseDescription = formValue("descriptionJa") || formValue("descriptionEn");
  const baseMunicipality = formValue("municipalityJa") || formValue("municipalityEn");
  const fallbackId = `${baseTitle || "spot"}-${Date.now()}`
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/(^-|-$)/g, "");
  return {
    id: existingId || fallbackId,
    group: formValue("spotGroup"),
    municipality: {
      en: formValue("municipalityEn") || baseMunicipality,
      ko: formValue("municipalityKo") || baseMunicipality,
      zh: formValue("municipalityZh") || baseMunicipality,
      ja: baseMunicipality,
    },
    lat: Number(formValue("latitude")),
    lng: Number(formValue("longitude")),
    image: images[0] || "",
    images,
    title: {
      en: formValue("titleEn") || baseTitle,
      ko: formValue("titleKo") || baseTitle,
      zh: formValue("titleZh") || baseTitle,
      ja: baseTitle,
    },
    description: {
      en: formValue("descriptionEn") || baseDescription,
      ko: formValue("descriptionKo") || baseDescription,
      zh: formValue("descriptionZh") || baseDescription,
      ja: baseDescription,
    },
  };
}

async function upsertSpot(spot) {
  let savedSpot = spot;
  try {
    if (cloud.enabled && state.cloudUser) savedSpot = await persistCloudSpot(spot);
  } catch {
    showStatus(t("cloudSyncFailed"));
    return;
  }
  const index = state.spots.findIndex((item) => item.id === savedSpot.id);
  if (index >= 0) {
    state.spots.splice(index, 1, savedSpot);
  } else {
    state.spots.unshift(savedSpot);
  }
  state.selectedId = savedSpot.id;
  if (!saveSpots()) return;
  clearDraftMarker();
  renderAll();
  map.flyTo([savedSpot.lat, savedSpot.lng], Math.max(map.getZoom(), 13), { duration: 0.55 });
  if (state.role === "editor") {
    resetForm(savedSpot);
    openDrawer();
  }
  showStatus(t("saved"));
  showCompletionNotification();
}

async function deleteCurrentSpot() {
  const id = formValue("spotId");
  if (!id) return;
  if (cloud.enabled && state.cloudUser) {
    try {
      await deleteCloudSpot(id);
    } catch {
      showStatus(t("cloudSyncFailed"));
      return;
    }
  }
  state.spots = state.spots.filter((spot) => spot.id !== id);
  state.selectedId = null;
  if (!saveSpots()) return;
  resetForm();
  renderAll();
  showStatus(t("deleted"));
}

function formatCoordinates(lat, lng) {
  return `${Number(lat).toFixed(6)}, ${Number(lng).toFixed(6)}`;
}

function parseLocationInfo(value) {
  const raw = String(value || "").trim();
  const dmsCoordinates = parseDmsCoordinates(raw);
  if (dmsCoordinates) return dmsCoordinates;

  const matches = raw.match(/-?\d+(?:\.\d+)?/g);
  if (!matches || matches.length < 2) return null;
  const lat = Number(matches[0]);
  const lng = Number(matches[1]);
  if (!Number.isFinite(lat) || !Number.isFinite(lng)) return null;
  if (Math.abs(lat) > 90 || Math.abs(lng) > 180) return null;
  return { lat, lng };
}

function parseDmsCoordinates(value) {
  const normalized = value
    .replace(/[，、]/g, " ")
    .replace(/[′’]/g, "'")
    .replace(/[″“”]/g, '"')
    .replace(/[北]/g, "N")
    .replace(/[南]/g, "S")
    .replace(/[東]/g, "E")
    .replace(/[西]/g, "W");
  const dmsPattern =
    /([NSWE])?\s*([+-]?\d+(?:\.\d+)?)\s*(?:°|度)\s*(?:(\d+(?:\.\d+)?)\s*(?:'|分)?)?\s*(?:(\d+(?:\.\d+)?)\s*(?:"|秒)?)?\s*([NSWE])?/gi;
  const parts = [];
  let match;
  while ((match = dmsPattern.exec(normalized))) {
    const direction = (match[1] || match[5] || "").toUpperCase();
    const decimal = dmsToDecimal(match[2], match[3], match[4], direction);
    if (!Number.isFinite(decimal)) continue;
    parts.push({ value: decimal, direction });
  }
  if (parts.length < 2) return null;

  const latPart = parts.find((part) => ["N", "S"].includes(part.direction)) || parts[0];
  const lngPart = parts.find((part) => ["E", "W"].includes(part.direction)) || parts.find((part) => part !== latPart) || parts[1];
  const lat = latPart.value;
  const lng = lngPart.value;
  if (Math.abs(lat) > 90 || Math.abs(lng) > 180) return null;
  return { lat, lng };
}

function dmsToDecimal(degrees, minutes = 0, seconds = 0, direction = "") {
  const degreeValue = Number(degrees);
  const sign = degreeValue < 0 || ["S", "W"].includes(direction) ? -1 : 1;
  const absoluteDegrees = Math.abs(degreeValue);
  return sign * (absoluteDegrees + Number(minutes || 0) / 60 + Number(seconds || 0) / 3600);
}

function updateDraftMarker(lat, lng, shouldFly = true) {
  if (!draftMarker) {
    draftMarker = L.circleMarker([lat, lng], {
      radius: 10,
      color: "#ffffff",
      weight: 3,
      fillColor: "#c85b43",
      fillOpacity: 0.95,
    }).addTo(map);
  } else {
    draftMarker.setLatLng([lat, lng]);
  }
  if (shouldFly) map.flyTo([lat, lng], Math.max(map.getZoom(), 13), { duration: 0.55 });
}

function clearDraftMarker() {
  if (!draftMarker) return;
  map.removeLayer(draftMarker);
  draftMarker = null;
}

function setCoordinates(lat, lng, options = {}) {
  const shouldFly = options.fly !== false;
  const numericLat = Number(lat);
  const numericLng = Number(lng);
  if (!Number.isFinite(numericLat) || !Number.isFinite(numericLng)) return false;
  els.latitude.value = numericLat.toFixed(6);
  els.longitude.value = numericLng.toFixed(6);
  els.locationInfo.value = formatCoordinates(numericLat, numericLng);
  updateDraftMarker(numericLat, numericLng, shouldFly);
  return true;
}

function syncLocationInfoToMap() {
  const parsed = parseLocationInfo(els.locationInfo.value);
  if (!parsed) return false;
  return setCoordinates(parsed.lat, parsed.lng);
}

function enableMapPick() {
  if (pickHandler) map.off("click", pickHandler);
  state.picking = true;
  showStatus(t("pickPrompt"));
  map.getContainer().style.cursor = "crosshair";
  pickHandler = (event) => {
    setCoordinates(event.latlng.lat, event.latlng.lng);
    map.getContainer().style.cursor = "";
    state.picking = false;
    map.off("click", pickHandler);
    pickHandler = null;
    showStatus(t("picked"));
  };
  map.on("click", pickHandler);
}

function exportData() {
  const blob = new Blob([JSON.stringify(state.spots, null, 2)], { type: "application/json" });
  const url = URL.createObjectURL(blob);
  const link = document.createElement("a");
  link.href = url;
  link.download = "noto-atlas-spots.json";
  link.click();
  URL.revokeObjectURL(url);
  showStatus(t("exportReady"));
}

function importData(file) {
  if (!file) return;
  const reader = new FileReader();
  reader.addEventListener("load", async () => {
    try {
      const imported = JSON.parse(String(reader.result));
      if (!Array.isArray(imported)) throw new Error("Expected an array");
      const validSpots = imported.filter((spot) => spot.id && Number.isFinite(Number(spot.lat)) && Number.isFinite(Number(spot.lng)));
      if (cloud.enabled && state.cloudUser) {
        await Promise.all(validSpots.map((spot) => persistCloudSpot(spot)));
      }
      state.spots = validSpots;
      if (!saveSpots()) return;
      state.activeGroup = null;
      state.selectedId = null;
      resetForm();
      renderAll();
      showStatus(t("imported"));
    } catch (error) {
      showStatus(error.message);
    }
  });
  reader.readAsText(file);
}

function readFileAsDataUrl(file) {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.addEventListener("load", () => resolve(String(reader.result || "")));
    reader.addEventListener("error", reject);
    reader.readAsDataURL(file);
  });
}

function readFileAsArrayBuffer(file) {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.addEventListener("load", () => resolve(reader.result));
    reader.addEventListener("error", reject);
    reader.readAsArrayBuffer(file);
  });
}

function loadImage(source) {
  return new Promise((resolve, reject) => {
    const image = new Image();
    image.addEventListener("load", () => resolve(image));
    image.addEventListener("error", reject);
    image.src = source;
  });
}

async function prepareInsertedPhoto(file) {
  const original = await readFileAsDataUrl(file);
  const image = await loadImage(original);
  const maxSide = 1400;
  const ratio = Math.min(1, maxSide / Math.max(image.naturalWidth, image.naturalHeight));
  const width = Math.max(1, Math.round(image.naturalWidth * ratio));
  const height = Math.max(1, Math.round(image.naturalHeight * ratio));
  const canvas = document.createElement("canvas");
  canvas.width = width;
  canvas.height = height;
  const context = canvas.getContext("2d", { alpha: false });
  context.drawImage(image, 0, 0, width, height);
  return canvas.toDataURL("image/jpeg", 0.84);
}

function readExifGpsFromArrayBuffer(buffer) {
  const view = new DataView(buffer);
  if (view.byteLength < 4 || view.getUint16(0) !== 0xffd8) return null;

  let offset = 2;
  while (offset + 4 < view.byteLength) {
    if (view.getUint8(offset) !== 0xff) break;
    const marker = view.getUint8(offset + 1);
    const length = view.getUint16(offset + 2);
    const dataStart = offset + 4;
    if (marker === 0xe1 && length >= 10) {
      const exifHeader = [0x45, 0x78, 0x69, 0x66, 0x00, 0x00];
      const isExif = exifHeader.every((byte, index) => view.getUint8(dataStart + index) === byte);
      if (isExif) {
        return readTiffGps(view, dataStart + 6);
      }
    }
    offset += 2 + length;
  }
  return null;
}

function readTiffGps(view, tiffStart) {
  const littleEndian = view.getUint16(tiffStart) === 0x4949;
  const get16 = (offset) => view.getUint16(offset, littleEndian);
  const get32 = (offset) => view.getUint32(offset, littleEndian);
  if (get16(tiffStart + 2) !== 0x002a) return null;

  const ifd0 = tiffStart + get32(tiffStart + 4);
  const gpsOffset = readIfdValueOffset(view, ifd0, 0x8825, tiffStart, get16, get32);
  if (!gpsOffset) return null;

  const gpsIfd = tiffStart + gpsOffset;
  const latRef = readIfdAscii(view, gpsIfd, 0x0001, tiffStart, get16, get32);
  const lat = readIfdRationals(view, gpsIfd, 0x0002, tiffStart, get16, get32);
  const lngRef = readIfdAscii(view, gpsIfd, 0x0003, tiffStart, get16, get32);
  const lng = readIfdRationals(view, gpsIfd, 0x0004, tiffStart, get16, get32);
  if (!lat || !lng) return null;

  const latitude = gpsToDecimal(lat) * (String(latRef).startsWith("S") ? -1 : 1);
  const longitude = gpsToDecimal(lng) * (String(lngRef).startsWith("W") ? -1 : 1);
  if (!Number.isFinite(latitude) || !Number.isFinite(longitude)) return null;
  return { lat: latitude, lng: longitude };
}

function readIfdEntry(view, ifdOffset, tag, get16) {
  const count = get16(ifdOffset);
  for (let index = 0; index < count; index += 1) {
    const entryOffset = ifdOffset + 2 + index * 12;
    if (get16(entryOffset) === tag) return entryOffset;
  }
  return 0;
}

function readIfdValueOffset(view, ifdOffset, tag, tiffStart, get16, get32) {
  const entry = readIfdEntry(view, ifdOffset, tag, get16);
  if (!entry) return 0;
  return get32(entry + 8);
}

function readIfdAscii(view, ifdOffset, tag, tiffStart, get16, get32) {
  const entry = readIfdEntry(view, ifdOffset, tag, get16);
  if (!entry) return "";
  const count = get32(entry + 4);
  const valueOffset = count <= 4 ? entry + 8 : tiffStart + get32(entry + 8);
  let value = "";
  for (let index = 0; index < count; index += 1) {
    const char = view.getUint8(valueOffset + index);
    if (char) value += String.fromCharCode(char);
  }
  return value;
}

function readIfdRationals(view, ifdOffset, tag, tiffStart, get16, get32) {
  const entry = readIfdEntry(view, ifdOffset, tag, get16);
  if (!entry) return null;
  const count = get32(entry + 4);
  const valueOffset = tiffStart + get32(entry + 8);
  const values = [];
  for (let index = 0; index < count; index += 1) {
    const numerator = get32(valueOffset + index * 8);
    const denominator = get32(valueOffset + index * 8 + 4);
    values.push(denominator ? numerator / denominator : 0);
  }
  return values;
}

function gpsToDecimal(values) {
  return values[0] + values[1] / 60 + values[2] / 3600;
}

async function readPhotoGps(file) {
  if (!/jpe?g$/i.test(file.name) && !/jpe?g/i.test(file.type)) return null;
  const buffer = await readFileAsArrayBuffer(file);
  return readExifGpsFromArrayBuffer(buffer);
}

async function findFirstPhotoGps(files) {
  for (const file of files) {
    try {
      const gps = await readPhotoGps(file);
      if (gps) return gps;
    } catch {
      // Continue scanning the remaining selected photos.
    }
  }
  return null;
}

async function prepareInsertedPhotos(files) {
  const prepared = [];
  for (const file of files) {
    prepared.push(await prepareInsertedPhoto(file));
  }
  return prepared;
}

async function translateWithBrowserApi(text, targetLanguage) {
  if (!text || !("Translator" in self)) return "";
  const pair = { sourceLanguage: "ja", targetLanguage };
  const availability = await self.Translator.availability(pair);
  if (availability === "unavailable") return "";
  if (!translatorCache.has(targetLanguage)) {
    const translator = await self.Translator.create(pair);
    if (translator.ready) await translator.ready;
    translatorCache.set(targetLanguage, translator);
  }
  return translatorCache.get(targetLanguage).translate(text);
}

function withTimeout(promise, milliseconds) {
  return Promise.race([
    promise,
    new Promise((resolve) => {
      window.setTimeout(() => resolve(""), milliseconds);
    }),
  ]);
}

function translateWithLocalMemory(text, targetLanguage) {
  const source = text.trim();
  const exact = translationMemory.get(source)?.[targetLanguage];
  if (exact) return exact;

  let translated = source;
  [...glossaryTerms[targetLanguage]]
    .sort((a, b) => b[0].length - a[0].length)
    .forEach(([ja, target]) => {
      translated = translated.replaceAll(ja, target);
    });

  if (targetLanguage === "en") {
    translated = translated
      .replaceAll("を紹介する", "introduces")
      .replaceAll("です", "")
      .replaceAll("市", " City")
      .replaceAll("町", " Town")
      .replaceAll("村", " Village")
      .replaceAll("区", " Ward")
      .replaceAll("の", " ")
      .replaceAll("と", " and ")
      .replaceAll("、", ", ")
      .replaceAll("。", ".")
      .replaceAll("・", " / ");
  }

  if (targetLanguage === "ko") {
    translated = translated.replaceAll("市", "시").replaceAll("町", "정").replaceAll("村", "촌").replaceAll("区", "구");
  }

  if (targetLanguage === "zh") {
    translated = translated.replaceAll("市", "市").replaceAll("町", "町").replaceAll("村", "村").replaceAll("区", "区");
  }

  return translated;
}

async function translateFromJapanese(text, targetLanguage) {
  if (!text.trim()) return "";
  const exact = translationMemory.get(text.trim())?.[targetLanguage];
  if (exact) return exact;
  try {
    const browserTranslation = await withTimeout(translateWithBrowserApi(text, targetLanguage), 900);
    if (browserTranslation) return browserTranslation;
  } catch {
    // Fall back to local terminology below.
  }
  return translateWithLocalMemory(text, targetLanguage);
}

function setAutoTranslatedValue(element, value, force = false) {
  if (!value) return;
  if (force || !element.value.trim() || element.dataset.autoTranslated === "true") {
    element.value = value;
    element.dataset.autoTranslated = "true";
  }
}

async function runAutoTranslate(force = false) {
  const titleJa = formValue("titleJa");
  const descriptionJa = formValue("descriptionJa");
  const municipalityJa = formValue("municipalityJa");
  if (!titleJa && !descriptionJa && !municipalityJa) return;

  showStatus(t("translating"));
  const titleTranslations = await Promise.all(
    translationTargets.map((language) => translateFromJapanese(titleJa, language)),
  );
  const descriptionTranslations = await Promise.all(
    translationTargets.map((language) => translateFromJapanese(descriptionJa, language)),
  );
  const municipalityTranslations = await Promise.all(
    translationTargets.map((language) => translateFromJapanese(municipalityJa, language)),
  );

  translationTargets.forEach((language, index) => {
    const titleElement = els[`title${language[0].toUpperCase()}${language.slice(1)}`];
    const descriptionElement = els[`description${language[0].toUpperCase()}${language.slice(1)}`];
    const municipalityElement = els[`municipality${language[0].toUpperCase()}${language.slice(1)}`];
    setAutoTranslatedValue(titleElement, titleTranslations[index], force);
    setAutoTranslatedValue(descriptionElement, descriptionTranslations[index], force);
    setAutoTranslatedValue(municipalityElement, municipalityTranslations[index], force);
  });
  showStatus(t("translated"));
}

function renderAll() {
  renderGroups();
  renderSpotList();
  renderMap();
}

function scheduleAutoTranslate() {
  window.clearTimeout(translationTimer);
  if (!els.autoTranslateToggle.checked) return;
  translationTimer = window.setTimeout(() => runAutoTranslate(false), 800);
}

els.languageSelect.addEventListener("change", (event) => {
  state.lang = event.target.value;
  renderI18n();
});

els.roleSelect.addEventListener("change", (event) => {
  const nextRole = event.target.value;
  if (nextRole === "editor") {
    event.target.value = state.role;
    requestEditorWorkspace();
    return;
  }
  closeDetailsMenu();
  lockEditorAccess();
});

els.editorModeButton.addEventListener("click", requestEditorWorkspace);

els.viewerModeButton.addEventListener("click", () => {
  closeDetailsMenu();
  lockEditorAccess();
});

document.addEventListener("click", (event) => {
  if (!els.detailsMenu?.open) return;
  if (!els.detailsMenu.contains(event.target)) closeDetailsMenu();
});

els.passkeyForm.addEventListener("submit", async (event) => {
  event.preventDefault();
  if (cloud.enabled) {
    try {
      const editorEmail = cloud.editorEmail || els.editorEmailInput.value.trim();
      if (!editorEmail) throw new Error("Missing editor email");
      const { data, error } = await cloud.client.auth.signInWithPassword({
        email: editorEmail,
        password: els.editorPasskeyInput.value,
      });
      if (error) throw error;
      state.cloudUser = data.user;
      unlockEditorAccess();
      return;
    } catch {
      if (els.editorPasskeyInput.value === EDITOR_PASSKEY) {
        state.cloudUser = null;
        unlockEditorAccess();
        return;
      }
      els.passkeyError.hidden = false;
      els.editorPasskeyInput.select();
      showStatus(t("editorSignInFailed"));
      return;
    }
  }
  if (els.editorPasskeyInput.value === EDITOR_PASSKEY) {
    unlockEditorAccess();
    return;
  }
  els.passkeyError.hidden = false;
  els.editorPasskeyInput.select();
  showStatus(t("editorPasskeyError"));
});

els.passkeyCancelButton.addEventListener("click", closePasskeyDialog);

document.addEventListener(
  "click",
  (event) => {
    const image = event.target.closest(
      ".spot-thumb img, .popup-thumb img, .photo-preview img, .photo-gallery img, .photo-marker img",
    );
    if (!image || els.imageLightbox.contains(image)) return;
    event.preventDefault();
    event.stopPropagation();
    openImageLightbox(image);
  },
  true,
);

els.imageLightboxClose.addEventListener("click", closeImageLightbox);

els.imageLightbox.addEventListener("click", (event) => {
  if (event.target === els.imageLightbox) closeImageLightbox();
});

document.addEventListener("keydown", (event) => {
  if (event.key !== "Escape") return;
  if (isImageLightboxOpen()) {
    closeImageLightbox();
    return;
  }
  if (els.passkeyModal.getAttribute("aria-hidden") !== "true") {
    closePasskeyDialog();
    return;
  }
  closeDetailsMenu();
});

els.groupList.addEventListener("click", (event) => {
  const button = event.target.closest("[data-group]");
  if (!button) return;
  state.activeGroup = button.dataset.group;
  state.selectedId = null;
  renderAll();
});

els.clearFilterButton.addEventListener("click", () => {
  state.activeGroup = null;
  state.selectedId = null;
  renderAll();
});

els.spotList.addEventListener("click", (event) => {
  const button = event.target.closest("[data-spot]");
  if (!button) return;
  selectSpot(button.dataset.spot);
});

document.addEventListener("click", (event) => {
  const editButton = event.target.closest("[data-edit-spot]");
  if (!editButton) return;
  selectSpot(editButton.dataset.editSpot, false);
});

els.newSpotButton.addEventListener("click", () => {
  state.selectedId = null;
  resetForm();
  openDrawer();
  renderSpotList();
});

els.closeDrawerButton.addEventListener("click", closeDrawer);

els.spotForm.addEventListener("submit", async (event) => {
  event.preventDefault();
  if (!syncLocationInfoToMap()) {
    showStatus(t("locationRequired"));
    return;
  }
  await runAutoTranslate(true);
  const spot = buildSpotFromForm();
  if (!Number.isFinite(spot.lat) || !Number.isFinite(spot.lng)) {
    showStatus(t("invalidLocation"));
    return;
  }
  await upsertSpot(spot);
});

els.deleteButton.addEventListener("click", () => {
  deleteCurrentSpot();
});

els.resetButton.addEventListener("click", () => {
  const spot = getSpot(formValue("spotId"));
  resetForm(spot || null);
});

els.translateButton.addEventListener("click", () => runAutoTranslate(true));

[els.titleJa, els.descriptionJa, els.municipalityJa].forEach((element) => {
  element.addEventListener("input", scheduleAutoTranslate);
});

[
  els.titleEn,
  els.titleKo,
  els.titleZh,
  els.descriptionEn,
  els.descriptionKo,
  els.descriptionZh,
  els.municipalityEn,
  els.municipalityKo,
  els.municipalityZh,
].forEach((element) => {
  element.addEventListener("input", () => {
    element.dataset.autoTranslated = "false";
  });
});

els.pickOnMapButton.addEventListener("click", enableMapPick);

els.currentLocationButton.addEventListener("click", () => {
  if (!navigator.geolocation) {
    showStatus(t("currentLocationFailed"));
    return;
  }
  navigator.geolocation.getCurrentPosition(
    (position) => {
      setCoordinates(position.coords.latitude, position.coords.longitude);
      showStatus(t("picked"));
    },
    () => showStatus(t("currentLocationFailed")),
    { enableHighAccuracy: true, timeout: 10000, maximumAge: 60000 },
  );
});

els.locationInfo.addEventListener("input", () => {
  if (!els.locationInfo.value.trim()) {
    els.latitude.value = "";
    els.longitude.value = "";
    clearDraftMarker();
    return;
  }
  syncLocationInfoToMap();
});

els.useCenterButton.addEventListener("click", () => {
  const center = map.getCenter();
  setCoordinates(center.lat, center.lng);
  showStatus(t("centerUsed"));
});

els.photoUrl.addEventListener("input", () => {
  state.draftImages = [];
  renderPreview();
});

els.photoFile.addEventListener("change", async (event) => {
  const files = Array.from(event.target.files || []);
  if (!files.length) return;
  try {
    const gps = await findFirstPhotoGps(files);
    state.draftImages = await prepareInsertedPhotos(files);
    renderPreview();
    if (gps) {
      setCoordinates(gps.lat, gps.lng);
      showStatus(t("photoLocationFound"));
    } else if (!els.locationInfo.value.trim()) {
      showStatus(t("photoLocationMissing"));
    }
  } catch {
    state.draftImages = [];
    renderPreview();
    showStatus(t("uploadFailed"));
  }
});

els.exportButton.addEventListener("click", exportData);

els.importInput.addEventListener("change", (event) => {
  importData(event.target.files?.[0]);
  event.target.value = "";
});

map.on("popupopen", () => {
  if (window.lucide) window.lucide.createIcons();
});

renderGroupOptions();
resetForm();
renderI18n();
renderRole();
initializeCloudBackend();

if (window.lucide) window.lucide.createIcons();
